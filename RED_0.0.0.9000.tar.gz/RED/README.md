# RED
R package for Robust Estimator of grade Difference (RED)

Download either the .zip or .tar.gz and install to your R Library
