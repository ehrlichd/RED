# RED
R package for Robust Estimator of grade Difference (RED)
